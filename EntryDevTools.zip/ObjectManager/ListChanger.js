Entry.variableContainer.getListByName('%0').setArray(%1.map(d => {return {data:d};}));
